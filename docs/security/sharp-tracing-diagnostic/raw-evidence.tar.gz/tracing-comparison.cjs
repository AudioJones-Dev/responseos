const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module'),crypto=require('node:crypto');
const build=JSON.parse(fs.readFileSync('.security-tools/archive-verification/artifact-verification/build-summary.json')),root=build.checkout,nft=createRequire(path.join(root,'package.json'))(path.join(root,'node_modules/next/dist/compiled/@vercel/nft'));
(async()=>{const observations=[];
 for(const entry of ['node_modules/@img/sharp-win32-x64/index.cjs','node_modules/sharp/dist/index.cjs','node_modules/next/dist/server/next-server.js'])for(const override of [false,true]){
 const options={base:root,processCwd:root,mixedModules:true,moduleSyncCatchall:true};if(override)options.readFile=async p=>{try{return await fs.promises.readFile(p,'utf8')}catch(e){if(['ENOENT','EISDIR'].includes(e.code))return '';throw e;}};
 const r=await nft.nodeFileTrace([path.join(root,entry)],options);const natives=[...r.fileList].filter(f=>f.includes('sharp-win32-x64')&&/\.(dll|node)$/.test(f)).map(file=>({file,reason:r.reasons.get(file)?{type:r.reasons.get(file).type,parents:[...r.reasons.get(file).parents]}:null}));
 observations.push({entry,utf8ReadOverride:override,total:r.fileList.size,natives,warnings:[...r.warnings].map(w=>w.message).slice(0,3)});console.log(JSON.stringify(observations.at(-1)));
 }
 fs.writeFileSync('.security-evidence/sharp-tracing-comparison.json',JSON.stringify({applicationSha:build.sourceCommit,scope:'NFT direct-entry comparison; actual original build unchanged',observations},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
